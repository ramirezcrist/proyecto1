#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/types.h>
#include <linux/slab.h>
#include <linux/sched.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <linux/seq_file.h>
#include <linux/proc_fs.h>

#define FileProc  "cpu_stat"
#define FileProc2 "cpu_200924468"

void readTree(struct seq_file *m, struct task_struct *s);

char get_State(struct task_struct *s)
{
    if(s->state == TASK_RUNNING){
        return 'R';    
    }else if(s->state == TASK_STOPPED){
        return 'T';
    }else if(s->state == TASK_INTERRUPTIBLE){
        return 'S';
    }else if(s->state == TASK_UNINTERRUPTIBLE){
        return 'D';
    }else if(s->state == EXIT_ZOMBIE){
        return 'Z';
    }else{
        return 'X';
    }    
}


static int pstree(struct seq_file *m, void *v)
{
    struct task_struct *root = current; 
     while (root->pid != 1)
        root = root->parent; 
    
    seq_printf(m,"Carné: 200924468\n");
    seq_printf(m,"Nombre: Cristian Ramirez\n");
    seq_printf(m,"Sistema Operativo: Fedora 27\n");	
    seq_printf(m,"====================PROCESOS=====================\n");
  
    readTree(m,root);
    return 0;
}

void readTree(struct seq_file *m, struct task_struct *s)
{
    struct list_head *list;
    struct task_struct *task;

    
    seq_printf(m,"Pid: %i === Nombre: %s === Estado:  %c\n", s->pid, s->comm, get_State(s));
                 
    list_for_each(list, &s->children) {

        task = list_entry(list, struct task_struct, sibling);
        readTree(m, task);
 
    }
}



static int processinfo_proc_open(struct inode *inode, struct file *file)
{
    return single_open(file, pstree, NULL);
}

static const struct file_operations procsinfo_proc_fops = {
    .open       = processinfo_proc_open,
    .read       = seq_read,
    .llseek     = seq_lseek,
    .release    = single_release,
};

static int __init start_function(void)
{
    printk(KERN_INFO "Cristian Ramirez::LOAD\n");
    proc_create(FileProc2, 0, NULL, &procsinfo_proc_fops); 
   
    return 0;
}

 
static void __exit clean_function(void)
{
    remove_proc_entry(FileProc, NULL); 
    printk(KERN_INFO "Sistemas Operativos 1::DOWNLOAD\n");
}
 
module_init(start_function);
module_exit(clean_function);
 
MODULE_AUTHOR("Cristian Alonso Ramirez Guzman");
MODULE_DESCRIPTION("Información y descripción de CPU");
MODULE_LICENSE("GPL");
