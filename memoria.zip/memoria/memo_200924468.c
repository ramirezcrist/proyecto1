#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <asm/uaccess.h>
#include <linux/hugetlb.h>
#include <linux/mm.h>
#include <linux/mman.h>
#include <linux/mmzone.h>
#include <linux/quicklist.h>
#include <linux/swap.h>
#include <linux/swapfile.h>
#include <linux/vmstat.h>
#include <linux/atomic.h>

#define FileProc "memoria_200924468"
struct sysinfo i;



static int show_memory_stat(struct seq_file *f, void *v){
    si_meminfo(&i); 

    seq_printf(f,"Carné: 200924468\n");
    seq_printf(f,"Nombre: Cristian Ramirez\n");
    seq_printf(f,"Sistema Operativo: Fedora 27\n");
    seq_printf(f,"====================MEMORIA=====================\n");
    seq_printf(f,"Total memoria: %8lu Mb\n", (i.totalram)/1000);
    seq_printf(f,"Memoria disponible: %8lu Mb\n", (i.freeram)/1000);
    seq_printf(f,"Memoria utilizada: %8lu \n", (((i.totalram)-(i.freeram))*100)/i.totalram);
    return 0;
}

static int meminfo_proc_open(struct inode *inode, struct file *file){
    return single_open(file, show_memory_stat, NULL);
}

static const struct file_operations Meminfo_fops = {
    .owner = THIS_MODULE,
    .open = meminfo_proc_open,
    .read = seq_read,
    .llseek = seq_lseek,
    .release = single_release,
};


static int __init start_function(void)
{
    printk(KERN_INFO "200924468::LOAD\n");
    proc_create(FileProc, 0, NULL, &Meminfo_fops);
  
    return 0;
}

static void __exit clean_function(void)
{
    remove_proc_entry(FileProc, NULL); 
    printk(KERN_INFO "Sistemos Operativos 1::DOWNLOAD\n");
}
 
module_init(start_function);
module_exit(clean_function);
 
MODULE_AUTHOR("Cristian Ramirez");
MODULE_DESCRIPTION("Datos e informacion: memoria ram");
MODULE_LICENSE("GPL");
